# Repozytorium przykładów do zajęć praktycznych
## dla uczniów 1dP, 1eRP, 3cI ZS3 w Olkuszu

Pamiętajcie proszę, że skrypty te nie są zestawem dobrych praktyk - ale mają zachęcić was do zgłębienia tematu. Często 
stosuję rozwiązania, które nie są optymalne, ale które pozwalą wam zrozumieć wybrane zagadnienia.

Możecie dowolnie modyfikować kod i przesyłać propozycje zmian.
Jeśli potrzebujecie wytłumaczenia - porozmawiamy na zajęciach.

Informacje, wprowadzenie i linki do dokumentacji są dostępne w moodle.

Milej zabawy  
Marcin Kłeczek
